const ctrl = {};
const path = require('path');
const { randomNumber } = require('../helpers/libs'); // Corregir la importación
const fs = require('fs-extra');
const {image} = require('../models');

ctrl.index = (req, res) => {
    res.send('Index page');
};

ctrl.create = async (req, res) => {
    try {
        const imgUrl = randomNumber(); // Si falta la implementación de randomNumber, se debe corregir
        const imageTempPath = req.file.path;
        const ext = path.extname(req.file.originalname).toLowerCase();
        const targetPath = path.resolve(`src/public/upload/${imgUrl}${ext}`);

        if (ext === '.png' || ext === '.jpg' || ext === '.jpeg') {
            await fs.rename(imageTempPath, targetPath);
            const newImg = new image ({
                title: req.body.title,
                filename: imgUrl + ext ,
                description : req.body.description
                
            });
            const imageSave= await newimage.save();
                

            res.send('works');
        } else {
            await fs.unlink(imageTempPath);
            res.status(400).json({ error: 'Only images are allowed' });
        }
    } catch (error) {
        console.error('Error uploading image:', error);
        res.status(500).send('Internal Server Error');
    }
};

ctrl.like = (req, res) => {
    // Implementar funcionalidad de like
};

ctrl.comments = (req, res) => {
    // Implementar funcionalidad de comentarios
};

ctrl.remove = (req, res) => {
    // Implementar funcionalidad de eliminación de imágenes
};

module.exports = ctrl;
