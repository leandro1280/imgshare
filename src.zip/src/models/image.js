const mongoose = require('mongoose');
const { Schema } = mongoose; // Corregido: Se debe usar `Schema` y no `Sheema`
const path = require('path');

// Definición del esquema de imagen
const imageSchema = new Schema({
    title: { type: String },
    description: { type: String },
    filename: { type: String },
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    timestamp: { type: Date, default: Date.now },
});
coonsole.log ('schema')

// Definición de un campo virtual `uniqueId`
imageSchema.virtual('uniqueId').get(function () {
    return this.filename.replace(path.extname(this.filename), '');
});

// Exportar el modelo
module.exports = mongoose.model('Image', imageSchema);
