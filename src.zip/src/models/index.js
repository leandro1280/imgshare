module.exports = { 
    image: require ('./image')
};